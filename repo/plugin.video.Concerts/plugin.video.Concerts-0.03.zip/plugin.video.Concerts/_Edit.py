import xbmcaddon

MainBase = 'https://pastebin.com/raw/sdXzNuVz'
addon = xbmcaddon.Addon('plugin.video.Concerts')